// src/components/TeamMember.jsx

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  ChevronDown,
  ChevronUp,
  GraduationCap,
  Briefcase,
  Award,
} from "lucide-react";

const TeamMember = ({ member }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileHover={{ scale: 1.02 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="team-member"
      onClick={() => setIsExpanded(!isExpanded)}
    >
      {/* Header */}
      <div className="team-member-header">
        {/* Member Image */}
        <div className="member-image">
          <img
            src={member.image}
            alt={`Photo of ${member.name}`}
            className="object-cover rounded-full"
            loading="lazy"
          />
        </div>

        {/* Member Name and Role */}
        <div className="text-center">
          <h3 className="member-name text-2xl font-bold text-gray-900">
            {member.name}
          </h3>
          <p className="member-role text-gray-600">{member.role}</p>
        </div>

        {/* School Logos */}
        {member.schoolLogos && member.schoolLogos.length > 0 && (
          <div className="school-logos-header">
            {member.schoolLogos.map((logo, index) => (
              <img
                key={index}
                src={logo.src}
                alt={`${
                  logo.isLarge ? "Primary" : "School"
                } Logo of ${member.name}`}
                className={`school-logo-header hover-scale-up transition-smooth ${
                  logo.isLarge ? "school-logo-large" : ""
                }`}
                loading="lazy"
              />
            ))}
          </div>
        )}

        {/* Expand/Collapse Indicator */}
        <div className="flex justify-center mt-4">
          {isExpanded ? (
            <ChevronUp size={24} className="text-gray-600" />
          ) : (
            <ChevronDown size={24} className="text-gray-600" />
          )}
        </div>
      </div>

      {/* Expanded Details */}
      {isExpanded && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="px-6 pb-6"
        >
          {member.education && (
            <div className="flex items-start mb-4">
              <GraduationCap
                size={20}
                className="text-gray-900 mr-2 flex-shrink-0 mt-1"
              />
              <div>
                <p className="text-gray-700">{member.education}</p>
                {/* Removed logos from description */}
              </div>
            </div>
          )}
          {member.experience && (
            <div className="flex items-start mb-4">
              <Briefcase
                size={20}
                className="text-gray-900 mr-2 flex-shrink-0 mt-1"
              />
              <p className="text-gray-700">{member.experience}</p>
            </div>
          )}
          {member.achievements && (
            <div className="flex items-start">
              <Award
                size={20}
                className="text-gray-900 mr-2 flex-shrink-0 mt-1"
              />
              <p className="text-gray-700">{member.achievements}</p>
            </div>
          )}
        </motion.div>
      )}
    </motion.div>
  );
};

export default TeamMember;
