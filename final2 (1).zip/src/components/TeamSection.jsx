// src/components/TeamSection.jsx

import React from "react";

const TeamSection = () => {
  return (
    <section className="py-20 bg-white" aria-labelledby="team-section-heading">
      <div className="container mx-auto px-6">
        <h2
          id="team-section-heading"
          className="text-4xl font-bold mb-12 text-center text-gray-900"
        >
          Our Affiliated Schools
        </h2>

        {/* Schools Logos */}
        <div className="schools-grid">
          {/* Replace with actual logo images and paths */}
          <div className="school-logo-container hover-scale-up transition-smooth">
            <img
              src="/assets/logos/columbia-logo.png"
              alt="Columbia University"
              className="school-logo-image"
            />
          </div>
          <div className="school-logo-container hover-scale-up transition-smooth">
            <img
              src="/assets/logos/cornell.png"
              alt="Cornell University"
              className="school-logo-image"
            />
          </div>
          <div className="school-logo-container hover-scale-up transition-smooth">
            <img
              src="/assets/logos/harvard-logo.png"
              alt="Harvard University"
              className="school-logo-image"
            />
          </div>
          <div className="school-logo-container hover-scale-up transition-smooth">
            <img
              src="/assets/logos/mit.png"
              alt="MIT"
              className="school-logo-image"
            />
          </div>
          <div className="school-logo-container hover-scale-up transition-smooth">
            <img
              src="/assets/logos/nyu-stern.png"
              alt="NYU Stern School of Business"
              className="school-logo-image"
            />
          </div>
          <div className="school-logo-container hover-scale-up transition-smooth">
            <img
              src="/assets/logos/nyu.png"
              alt="NYU"
              className="school-logo-image"
            />
          </div>
          <div className="school-logo-container hover-scale-up transition-smooth">
            <img
              src="/assets/logos/upenn.png"
              alt="University of Pennsylvania"
              className="school-logo-image"
            />
          </div>
          {/* Add more logos as needed */}
        </div>
      </div>
    </section>
  );
};

export default TeamSection;
