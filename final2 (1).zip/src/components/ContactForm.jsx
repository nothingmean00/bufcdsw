// src/components/ContactForm.jsx

import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { motion } from 'framer-motion';
import emailjs from '@emailjs/browser';

const ContactForm = () => {
  const initialFormData = {
    studentName: '',
    parentName: '',
    email: '',
    phone: '',
    gpa: '',
    satScore: '', // Now optional
    interests: '',
    extracurriculars: '', // New field
    message: '',
  };

  const [formData, setFormData] = useState(initialFormData);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionError, setSubmissionError] = useState('');

  // EmailJS credentials
  const serviceID = 'service_pwzfu5m'; // Replace with your actual service ID
  const templateID = 'template_5w6d10r'; // Replace with your actual template ID
  const publicKey = '1f0O7g7OcoCj7UZDM'; // Replace with your actual public key

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;

    // Ensure GPA and SAT score are numbers
    if ((name === 'gpa' || name === 'satScore') && value !== '') {
      if (!/^\d*\.?\d*$/.test(value)) {
        return;
      }
    }

    setFormData({ ...formData, [name]: value });

    // Remove error message upon input change
    if (errors[name]) {
      setErrors({ ...errors, [name]: '' });
    }
  };

  // Validate form data
  const validate = () => {
    const newErrors = {};
    if (!formData.studentName.trim())
      newErrors.studentName = 'Student name is required.';
    if (!formData.parentName.trim())
      newErrors.parentName = 'Parent/Guardian name is required.';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required.';
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)
    ) {
      newErrors.email = 'Invalid email address.';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required.';
    } else if (!/^\+?\d{7,15}$/.test(formData.phone)) {
      newErrors.phone = 'Invalid phone number.';
    }
    if (!formData.gpa.trim()) newErrors.gpa = 'GPA is required.';
    // SAT score is now optional, so we remove its validation
    if (!formData.interests.trim())
      newErrors.interests = 'Academic interests are required.';
    if (!formData.extracurriculars.trim())
      newErrors.extracurriculars = 'Please provide information about extracurricular activities.';
    if (!formData.message.trim())
      newErrors.message = 'Please provide additional details.';

    return newErrors;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmissionError('');
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsSubmitting(true);

    try {
      // Send the email via EmailJS
      const result = await emailjs.send(
        serviceID,
        templateID,
        {
          studentName: formData.studentName,
          parentName: formData.parentName,
          email: formData.email,
          phone: formData.phone,
          gpa: formData.gpa,
          satScore: formData.satScore,
          interests: formData.interests,
          extracurriculars: formData.extracurriculars,
          message: formData.message,
        },
        publicKey
      );

      console.log('Form Submitted:', result.text);

      setSubmitted(true);
      setFormData(initialFormData);
    } catch (error) {
      console.error('Form Submission Error:', error);
      setSubmissionError(
        'An error occurred while submitting the form. Please try again later.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      {submitted ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <h3 className="text-2xl font-semibold text-gray-900 mb-4">
            Thank You!
          </h3>
          <p className="text-gray-700">
            Your request for a free assessment has been received. We'll contact you shortly.
          </p>
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6" noValidate>
          {/* Student Name */}
          <div>
            <label
              htmlFor="studentName"
              className="block text-gray-700 font-semibold mb-2"
            >
              Student Name<span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="studentName"
              name="studentName"
              className={`w-full px-4 py-2 border ${
                errors.studentName
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.studentName}
              onChange={handleChange}
              aria-invalid={errors.studentName ? 'true' : 'false'}
              aria-describedby={
                errors.studentName ? 'studentName-error' : undefined
              }
              required
            />
            {errors.studentName && (
              <p
                id="studentName-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.studentName}
              </p>
            )}
          </div>

          {/* Parent/Guardian Name */}
          <div>
            <label
              htmlFor="parentName"
              className="block text-gray-700 font-semibold mb-2"
            >
              Parent/Guardian Name<span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="parentName"
              name="parentName"
              className={`w-full px-4 py-2 border ${
                errors.parentName
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.parentName}
              onChange={handleChange}
              aria-invalid={errors.parentName ? 'true' : 'false'}
              aria-describedby={
                errors.parentName ? 'parentName-error' : undefined
              }
              required
            />
            {errors.parentName && (
              <p
                id="parentName-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.parentName}
              </p>
            )}
          </div>

          {/* Email */}
          <div>
            <label
              htmlFor="email"
              className="block text-gray-700 font-semibold mb-2"
            >
              Email<span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              id="email"
              name="email"
              className={`w-full px-4 py-2 border ${
                errors.email
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.email}
              onChange={handleChange}
              aria-invalid={errors.email ? 'true' : 'false'}
              aria-describedby={errors.email ? 'email-error' : undefined}
              required
            />
            {errors.email && (
              <p
                id="email-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.email}
              </p>
            )}
          </div>

          {/* Phone */}
          <div>
            <label
              htmlFor="phone"
              className="block text-gray-700 font-semibold mb-2"
            >
              Phone Number<span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              className={`w-full px-4 py-2 border ${
                errors.phone
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.phone}
              onChange={handleChange}
              aria-invalid={errors.phone ? 'true' : 'false'}
              aria-describedby={errors.phone ? 'phone-error' : undefined}
              required
            />
            {errors.phone && (
              <p
                id="phone-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.phone}
              </p>
            )}
          </div>

          {/* GPA */}
          <div>
            <label
              htmlFor="gpa"
              className="block text-gray-700 font-semibold mb-2"
            >
              GPA<span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="gpa"
              name="gpa"
              className={`w-full px-4 py-2 border ${
                errors.gpa
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.gpa}
              onChange={handleChange}
              aria-invalid={errors.gpa ? 'true' : 'false'}
              aria-describedby={errors.gpa ? 'gpa-error' : undefined}
              required
            />
            {errors.gpa && (
              <p
                id="gpa-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.gpa}
              </p>
            )}
          </div>

          {/* SAT Score (Optional) */}
          <div>
            <label
              htmlFor="satScore"
              className="block text-gray-700 font-semibold mb-2"
            >
              SAT Score (Optional)
            </label>
            <input
              type="text"
              id="satScore"
              name="satScore"
              className={`w-full px-4 py-2 border ${
                errors.satScore
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.satScore}
              onChange={handleChange}
              aria-invalid={errors.satScore ? 'true' : 'false'}
              aria-describedby={errors.satScore ? 'satScore-error' : undefined}
            />
            {errors.satScore && (
              <p
                id="satScore-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.satScore}
              </p>
            )}
          </div>

          {/* Extracurricular Activities */}
          <div>
            <label
              htmlFor="extracurriculars"
              className="block text-gray-700 font-semibold mb-2"
            >
              Clubs and Extracurricular Activities<span className="text-red-500">*</span>
            </label>
            <textarea
              id="extracurriculars"
              name="extracurriculars"
              rows="4"
              className={`w-full px-4 py-2 border ${
                errors.extracurriculars
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.extracurriculars}
              onChange={handleChange}
              aria-invalid={errors.extracurriculars ? 'true' : 'false'}
              aria-describedby={errors.extracurriculars ? 'extracurriculars-error' : undefined}
              required
            ></textarea>
            {errors.extracurriculars && (
              <p
                id="extracurriculars-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.extracurriculars}
              </p>
            )}
          </div>

          {/* Academic Interests */}
          <div>
            <label
              htmlFor="interests"
              className="block text-gray-700 font-semibold mb-2"
            >
              Academic Interests<span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="interests"
              name="interests"
              className={`w-full px-4 py-2 border ${
                errors.interests
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.interests}
              onChange={handleChange}
              aria-invalid={errors.interests ? 'true' : 'false'}
              aria-describedby={errors.interests ? 'interests-error' : undefined}
              required
            />
            {errors.interests && (
              <p
                id="interests-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.interests}
              </p>
            )}
          </div>

          {/* Additional Details */}
          <div>
            <label
              htmlFor="message"
              className="block text-gray-700 font-semibold mb-2"
            >
              Additional Details<span className="text-red-500">*</span>
            </label>
            <textarea
              id="message"
              name="message"
              rows="4"
              className={`w-full px-4 py-2 border ${
                errors.message
                  ? 'border-red-500'
                  : 'border-gray-300 focus:border-gray-900'
              } rounded-md focus:outline-none focus:ring-2 focus:ring-gray-900`}
              value={formData.message}
              onChange={handleChange}
              aria-invalid={errors.message ? 'true' : 'false'}
              aria-describedby={errors.message ? 'message-error' : undefined}
              required
            ></textarea>
            {errors.message && (
              <p
                id="message-error"
                className="mt-1 text-red-500 text-sm"
                role="alert"
              >
                {errors.message}
              </p>
            )}
          </div>

          {/* Submission Error */}
          {submissionError && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-500 text-sm text-center"
              role="alert"
            >
              {submissionError}
            </motion.p>
          )}

          {/* Submit Button */}
          <div>
            <button
              type="submit"
              className={`w-full bg-gray-900 text-white px-4 py-2 rounded-full font-semibold hover:bg-gray-800 transition-colors flex items-center justify-center ${
                isSubmitting ? 'cursor-not-allowed opacity-50' : ''
              }`}
              disabled={isSubmitting}
              aria-disabled={isSubmitting}
            >
              {isSubmitting ? 'Submitting...' : 'Schedule Free Assessment'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

ContactForm.propTypes = {
  // No props currently, but define if needed in the future
};

export default ContactForm;
