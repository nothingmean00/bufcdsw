// src/pages/ContactPage.jsx

import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { Helmet } from 'react-helmet';

import ContactForm from '../components/ContactForm';
import ContactInfo from '../components/ContactInfo';
import FAQItem from '../components/FAQItem';

// Complete FAQs data with unique IDs
const faqs = [
  {
    id: 1,
    question: 'How do I schedule a free assessment?',
    answer:
      'You can schedule your free assessment by filling out the form on this page. Provide your details, and one of our counselors will reach out to you within 24 hours to set up your assessment.',
  },
  {
    id: 2,
    question: 'What does the free assessment include?',
    answer:
      'Our free assessment includes a comprehensive review of your academic profile, extracurricular activities, and college aspirations. We provide personalized recommendations to enhance your admissions prospects.',
  },
  {
    id: 3,
    question: 'Are there any obligations after the free assessment?',
    answer:
      'No, there are no obligations. The free assessment is our way of providing value upfront. If you find our services beneficial, we can discuss customized plans to support your college admissions journey.',
  },
  {
    id: 4,
    question: 'How many free assessments are available?',
    answer:
      'We offer a limited number of free assessments each month to ensure personalized attention. Currently, we have only 9 free assessments left this month, so we encourage you to schedule yours soon.',
  },
  {
    id: 5,
    question: 'Can international students apply for the free assessment?',
    answer:
      'Yes, we welcome international students. Our counselors are experienced in guiding students through the unique challenges of international college admissions.',
  },
];

const ContactPage = () => {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans flex flex-col">
      {/* SEO Meta Tags */}
      <Helmet>
        <title>Contact Us - Ascend Consulting</title>
        <meta
          name="description"
          content="Schedule your free college admissions assessment with Ascend Consulting. Provide your details to get personalized guidance from our expert counselors."
        />
      </Helmet>

      <main className="flex-grow">
        {/* Hero Section */}
        <section
          className="relative pt-32 pb-12 flex items-center justify-center overflow-hidden text-center"
          style={{
            background: 'linear-gradient(135deg, #1F2937 0%, #374151 100%)',
          }}
          aria-labelledby="contact-hero-heading"
        >
          {/* Overlay for better text readability */}
          <div
            className="absolute inset-0 bg-black opacity-30"
            aria-hidden="true"
          ></div>
          <div className="container mx-auto px-6 relative z-10">
            <motion.h1
              id="contact-hero-heading"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-5xl font-bold mb-4 text-white"
            >
              Schedule Your Free Assessment
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-2xl text-gray-300 mb-8 max-w-3xl mx-auto"
            >
              Provide your details below, and our expert counselors will help you
              chart the path to your dream college.
            </motion.p>
          </div>
        </section>

        {/* Contact and FAQ Section */}
        <section
          className="py-20 bg-gray-50"
          aria-labelledby="contact-faq-section-heading"
        >
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <ContactForm />
              </motion.div>

              {/* Contact Information and FAQs */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <ContactInfo />

                {/* FAQs */}
                <div className="mt-12">
                  <h3
                    id="contact-faq-section-heading"
                    className="text-2xl font-bold mb-6 text-gray-900"
                  >
                    Frequently Asked Questions
                  </h3>
                  <div className="space-y-4">
                    {faqs.map((faq) => (
                      <FAQItem
                        key={faq.id}
                        id={faq.id}
                        question={faq.question}
                        answer={faq.answer}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Call to Action Section */}
        <section
          className="py-20 bg-gray-100"
          aria-labelledby="contact-cta-heading"
        >
          <div className="container mx-auto px-6 text-center">
            <motion.h3
              id="contact-cta-heading"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-3xl font-bold mb-8 text-gray-900"
            >
              Don't Miss Out on Your Free Assessment!
            </motion.h3>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-xl mb-12 max-w-2xl mx-auto text-gray-700"
            >
              Limited spots are available this month. Take the first step towards
              academic success by scheduling your free assessment today.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileHover={{ scale: 1.05 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <Link
                to="/contact"
                className="bg-gray-900 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-gray-800 transition-all hover:shadow-lg inline-flex items-center group"
                aria-label="Schedule Your Free Assessment with Ascend Consulting"
              >
                Schedule Now
                <ChevronRight
                  size={20}
                  className="ml-2 transition-transform group-hover:translate-x-1"
                  aria-hidden="true"
                />
              </Link>
            </motion.div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default ContactPage;
