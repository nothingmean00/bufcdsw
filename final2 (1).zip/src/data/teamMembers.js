// src/data/teamMembers.js

// Import the school logos
import columbiaLogo from "../assets/logos/columbia-logo.png";
import nyuSternLogo from "../assets/logos/nyu-stern.png";
import mitLogo from "../assets/logos/mit.png";
import cornellLogo from "../assets/logos/cornell.png";
import upennLogo from "../assets/logos/upenn.png";
import nyuLogo from "../assets/logos/nyu.png";
import harvardLogo from "../assets/logos/harvard.png";
// Add more logo imports as needed

export const teamMembers = [
  {
    name: "Zehua",
    role: "General Counselor",
    education:
      "Graduate of Columbia University, focused on Mathematics and Statistics.",
    experience:
      "Zehua has interned as a Credit Analyst at Bank of China USA and as a Quantitative Analyst at Guotai Junan Securities Co., Ltd., providing him with valuable insights into the financial sector and the challenges faced by international students.",
    achievements: "",
    image: "/images/zehua.jpg", // Replace with actual image path
    schoolLogos: [
      { src: columbiaLogo, isLarge: true }, // Columbia logo marked as large
    ],
  },
  {
    name: "Malik",
    role: "General Counselor",
    education:
      "With a degree from NYU Stern School of Business, Malik offers expertise in finance-related majors and entrepreneurship.",
    experience:
      "His diverse experience includes working as an Investment Solutions Analyst at SigTech and gaining valuable insights in private equity at Bregal Investments. As an entrepreneur who has created his own companies, Malik provides unique perspectives on business innovation and start-up dynamics.",
    achievements: "",
    image: "/images/malik.jpg", // Replace with actual image path
    schoolLogos: [
      { src: nyuSternLogo, isLarge: false },
    ],
  },
  // *** Moved Steven's Entry After Malik ***
  {
    name: "Steven",
    role: "Interview Specialist",
    education:
      "Steven, a Cornell University graduate, brings a wealth of experience from the finance sector.",
    experience:
      "He honed his skills as an Investment Banker at Wells Fargo’s Real Estate, Gaming, Lodging and Leisure Group, gaining deep insights into these specialized industries. Currently serving as an Investment Associate at MIT, Steven leverages his diverse background to prepare students for university interviews.",
    achievements:
      "Steven’s unique combination of corporate and academic experience provides students with invaluable insights into both university admissions and future career paths.",
    image: "/images/steven.jpg", // Replace with actual image path
    schoolLogos: [
      { src: cornellLogo, isLarge: true }, // Cornell logo marked as large
      { src: mitLogo, isLarge: true },      // MIT logo marked as large
    ],
  },
  {
    name: "Sabiq",
    role: "Essay Specialist",
    education:
      "An NYU graduate in Economics and Journalism, excels in helping students craft compelling narratives.",
    experience:
      "His experience as a Journalist at the Financial Times enables him to guide students in writing impactful essays that stand out in competitive U.S. university applications.",
    achievements: "",
    image: "/images/sabiq.jpg", // Replace with actual image path
    schoolLogos: [
      { src: nyuLogo, isLarge: false },
    ],
  },
  {
    name: "Anjali",
    role: "SAT/ACT Specialist",
    education:
      "Currently an Electrical Engineering student at the University of Pennsylvania.",
    experience: "",
    achievements:
      "Scored in the 99th percentile on the SAT. She uses her recent experience to provide targeted strategies for students preparing for these crucial standardized tests required by top U.S. universities.",
    image: "/images/anjali.jpg", // Replace with actual image path
    schoolLogos: [
      { src: upennLogo, isLarge: false },
    ],
  },
  {
    name: "Marc",
    role: "Academic Specialist",
    education:
      "Marc, who studied Economics at Harvard University, offers invaluable insights into the academic expectations of elite U.S. institutions.",
    experience:
      "His experience tutoring hundreds of Harvard students allows him to guide applicants in preparing for the rigorous academic environment of top American universities.",
    achievements: "",
    image: "/images/marc.jpg", // Replace with actual image path
    schoolLogos: [
      { src: harvardLogo, isLarge: false },
    ],
  },
  {
    name: "Abiel",
    role: "Strategy Specialist",
    education:
      "A graduate of NYU Stern School of Business with experience at LVMH, Abiel specializes in helping students develop a comprehensive application strategy.",
    experience:
      "His background in management and fashion industries provides unique perspectives for students interested in business or creative fields at U.S. universities.",
    achievements: "",
    image: "/images/abiel.jpg", // Replace with actual image path
    schoolLogos: [
      { src: nyuSternLogo, isLarge: false },
    ],
  },
  // ... add more team members as needed
];
